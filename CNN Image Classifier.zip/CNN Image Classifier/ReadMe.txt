# CNN Image Classification App

This project is a Flask web application that allows users to upload an image
and get predictions from a CNN trained on the CIFAR-10 dataset.

#To Run:
1. Install:
   pip install -r requirements.txt

2. Train the model:
   python train.py

3. Start the website:
   python app.py

4. Open browser:
   http://127.0.0.1:5000