from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np
import os

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

model = load_model("cnn_cifar10_model.h5")

class_names = [
    "Airplane", "Car", "Bird", "Cat", "Deer",
    "Dog", "Frog", "Horse", "Ship", "Truck"
]

def prepare_image(image):
    image = image.resize((32, 32))
    image = np.array(image) / 255.0
    image = image.reshape(1, 32, 32, 3)
    return image

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = confidence = image_path = None

    if request.method == "POST":
        file = request.files["image"]
        if file:
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
            image_path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(image_path)

            image = Image.open(image_path).convert("RGB")
            image = prepare_image(image)

            preds = model.predict(image)
            idx = np.argmax(preds)
            prediction = class_names[idx]
            confidence = round(float(np.max(preds)) * 100, 2)

    return render_template("index.html",
                           prediction=prediction,
                           confidence=confidence,
                           image_path=image_path)

if __name__ == "__main__":
    app.run(debug=True)